// index.js for NotifyEvents Appwrite Function

module.exports = async ({ req, res, log, error }) => {
  // Extract event type and payload
  const eventType = req.headers["x-appwrite-event"];
  const payload = req.body;

  // Example: Notification logic for different events
  if (eventType.includes("tasks.documents.*.create")) {
    log("Task created: " + JSON.stringify(payload));
    // TODO: Send notification to assigned user(s)
  }
  if (eventType.includes("tasks.documents.*.update")) {
    log("Task updated: " + JSON.stringify(payload));
    // TODO: Notify user(s) about assignment/status change
  }
  if (eventType.includes("tasks.documents.*.delete")) {
    log("Task deleted: " + JSON.stringify(payload));
    // TODO: Notify user(s) about task deletion
  }
  if (eventType.includes("comments.documents.*.create")) {
    log("Comment added: " + JSON.stringify(payload));
    // TODO: Notify relevant user(s) about new comment
  }

  res.json({ success: true });
};
